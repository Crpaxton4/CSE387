#include "CubeShapeActor.h"



CubeShapeActor::CubeShapeActor(class Game* game) :Actor(game)
{

}


CubeShapeActor::~CubeShapeActor()
{
}
