#pragma once
#include "Actor.h"
class CubeShapeActor :
	public Actor
{
public:
	CubeShapeActor(class Game* game);
	~CubeShapeActor();
};

