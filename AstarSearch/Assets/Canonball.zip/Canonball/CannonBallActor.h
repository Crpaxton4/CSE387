#pragma once
#include "Actor.h"
class CannonBallActor :	public Actor
{
public:
	CannonBallActor(class Game* game);

};

