#include "CannonBallActor.h"
#include "SpriteComponent.h"
#include "MoveComponent.h"
#include "Random.h"
#include "PhysicalMovementComponent.h"
#include "Game.h"


CannonBallActor::CannonBallActor(Game* game)
	:Actor(game)
{
	// Create a sprite component
	SpriteComponent* sc = new SpriteComponent(this);
	sc->SetTexture(game->GetTexture("Assets/BulletBillWii.png"));

	// Create a move component, and set a forward speed
	PhysicalMovementComponent* mc = new PhysicalMovementComponent(this);

	mc->SetVelocity(250.0f * vec2(1, -1));




}

